prop=$1
value=$2

perl -i -lane 'if(/'$prop'/){print "'$prop'=\"'$value'\""}else{print}' config.sh
