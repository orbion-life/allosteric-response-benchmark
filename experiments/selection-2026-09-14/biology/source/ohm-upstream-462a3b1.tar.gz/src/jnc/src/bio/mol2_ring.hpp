#pragma once

namespace jnc {
namespace bio {

struct Ring : public std::vector<int> {
};

void identify_rings(const Mol2 &m) {
    for (int i = 0; i < n; i++) {
        st.push_back(i);
        for (auto && j : connected_indices[i]) {
            traverse(j);
        }
        st.pop_back();
    }
}

}
}

